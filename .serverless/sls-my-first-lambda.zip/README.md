# serverless-lambda-first-steps
Lambda function with serverless framework 
